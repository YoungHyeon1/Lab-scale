from sqlalchemy.ext.declarative import declarative_base

Model = declarative_base()