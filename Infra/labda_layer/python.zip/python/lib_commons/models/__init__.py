from .base import Model

__all__ = [
    'Model',
]